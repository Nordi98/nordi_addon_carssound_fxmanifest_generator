@echo off
powershell -ExecutionPolicy Bypass -NoExit -File "%~dp0generate_manifest.ps1"
pause
