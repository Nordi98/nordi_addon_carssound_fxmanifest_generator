# generate_manifest.ps1
# generate.bat benutzen zum Starten

$audioconfigDir = "audioconfig"
$sfxDir         = "sfx"
$outputFile     = "fxmanifest.lua"

Write-Host "Scanne Ordner..." -ForegroundColor Cyan

# Alle _game.dat151.rel Dateien finden -> Name extrahieren
$gameDats = Get-ChildItem -Path $audioconfigDir -Filter "*_game.dat151.rel" | Sort-Object Name

# Alle sfx Unterordner finden
$sfxDirs = Get-ChildItem -Path $sfxDir -Directory | Select-Object -ExpandProperty Name

Write-Host "Gefunden: $($gameDats.Count) audioconfig Eintraege"
Write-Host "Gefunden: $($sfxDirs.Count) sfx Ordner"

# Manifest aufbauen
$lines = @()
$lines += "fx_version 'cerulean'"
$lines += "game 'gta5'"
$lines += "description 'Addon Sounds'"
$lines += "version '1.0.0'"
$lines += "lua54 'yes'"
$lines += ""

foreach ($file in $gameDats) {
    # "gb811s2_game.dat151.rel" -> "gb811s2"
    $name = $file.Name -replace "_game\.dat151\.rel$", ""

    # Einträge OHNE .rel Extension, nur _game.dat und _sounds.dat
    $lines += "data_file `"AUDIO_GAMEDATA`"  `"audioconfig/${name}_game.dat`""
    $lines += "data_file `"AUDIO_SOUNDDATA`" `"audioconfig/${name}_sounds.dat`""

    $sfxName = "dlc_$name"
    if ($sfxDirs -contains $sfxName) {
        $lines += "data_file `"AUDIO_WAVEPACK`"   `"sfx/$sfxName`""
    } else {
        $lines += "-- KEIN SFX ORDNER GEFUNDEN FUER: $sfxName"
    }

    $lines += ""
}

$lines += "files {"
$lines += "    'audioconfig/*.dat151.rel',"
$lines += "    'audioconfig/*.dat54.rel',"
$lines += "    'audioconfig/*.nametable',"
$lines += "    'sfx/**/*.awc'"
$lines += "}"
$lines += ""
$lines += "dependency '/assetpacks'"

# Datei schreiben
$lines | Set-Content -Path $outputFile -Encoding UTF8

Write-Host ""
Write-Host "Fertig! $outputFile wurde generiert." -ForegroundColor Green
Write-Host ""
Read-Host "Drücke Enter zum Beenden"
